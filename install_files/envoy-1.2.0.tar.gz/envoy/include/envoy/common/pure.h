#pragma once

/**
 * Friendly name for a pure virtual routine.
 */
#define PURE = 0
