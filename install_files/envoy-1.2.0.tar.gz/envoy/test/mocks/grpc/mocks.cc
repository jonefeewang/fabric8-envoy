#include "mocks.h"

namespace Grpc {

MockRpcChannelCallbacks::MockRpcChannelCallbacks() {}
MockRpcChannelCallbacks::~MockRpcChannelCallbacks() {}

MockRpcChannel::MockRpcChannel() {}
MockRpcChannel::~MockRpcChannel() {}

} // Grpc
