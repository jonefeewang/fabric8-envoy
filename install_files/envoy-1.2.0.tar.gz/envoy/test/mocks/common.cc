#include "common.h"

ReadyWatcher::ReadyWatcher() {}
ReadyWatcher::~ReadyWatcher() {}

MockSystemTimeSource::MockSystemTimeSource() {}
MockSystemTimeSource::~MockSystemTimeSource() {}
