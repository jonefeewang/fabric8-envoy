#include "mocks.h"

namespace RateLimit {

MockClient::MockClient() {}
MockClient::~MockClient() {}

} // RateLimit
