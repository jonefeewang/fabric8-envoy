#include "mocks.h"

namespace Ssl {

MockContextManager::MockContextManager() {}
MockContextManager::~MockContextManager() {}

MockConnection::MockConnection() {}
MockConnection::~MockConnection() {}

MockClientContext::MockClientContext() {}
MockClientContext::~MockClientContext() {}

} // Ssl
