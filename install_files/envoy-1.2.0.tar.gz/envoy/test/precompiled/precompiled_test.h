#pragma once

#include "precompiled/precompiled.h"

#include "test/test_common/printers.h"

#include "gmock/gmock.h"
#include "gtest/gtest.h"
