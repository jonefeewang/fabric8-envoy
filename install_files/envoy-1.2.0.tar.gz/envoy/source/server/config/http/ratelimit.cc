#include "ratelimit.h"

#include "common/http/filter/ratelimit.h"

namespace Server {
namespace Configuration {

HttpFilterFactoryCb RateLimitFilterConfig::tryCreateFilterFactory(HttpFilterType type,
                                                                  const std::string& name,
                                                                  const Json::Object& config,
                                                                  const std::string&,
                                                                  Server::Instance& server) {
  if (type != HttpFilterType::Decoder || name != "rate_limit") {
    return nullptr;
  }

  Http::RateLimit::FilterConfigPtr filter_config(new Http::RateLimit::FilterConfig(
      config, server.localInfo(), server.stats(), server.runtime(), server.clusterManager()));
  return [filter_config, &server](Http::FilterChainFactoryCallbacks& callbacks) -> void {
    callbacks.addStreamDecoderFilter(Http::StreamDecoderFilterPtr{new Http::RateLimit::Filter(
        filter_config, server.rateLimitClient(std::chrono::milliseconds(20)))});
  };
}

/**
 * Static registration for the rate limit filter. @see RegisterHttpFilterConfigFactory.
 */
static RegisterHttpFilterConfigFactory<RateLimitFilterConfig> register_;

} // Configuration
} // Server
