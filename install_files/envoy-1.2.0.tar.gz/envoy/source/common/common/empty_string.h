#pragma once

static const std::string EMPTY_STRING = "";
