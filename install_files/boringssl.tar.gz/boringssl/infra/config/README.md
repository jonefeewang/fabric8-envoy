Infrastructure location.

This contains Commit Queue config for automatic testing of changes before they
are committed.

Initial set up bug: http://crbug.com/618641.
